<script setup>
	// #ifdef APP-ANDROID || APP-HARMONY
	let firstBackTime = 0
	// #endif

	import { checkBlocked, startBlockedWatch, guardIfBlocked } from '@/utils/blocked.js'

	onLaunch(async () => {
		console.log('App Launch')
		await checkBlocked()
		startBlockedWatch()
		guardIfBlocked()
	})

	onAppShow(() => {
		console.log('App Show')
		guardIfBlocked()
	})

	onAppHide(() => {
		console.log('App Hide')
	})

	// #ifdef APP-ANDROID || APP-HARMONY
	onLastPageBackPress(() => {
		console.log('App LastPageBackPress')
		if (firstBackTime == 0) {
			uni.showToast({
				title: '再按一次退出应用',
				position: 'bottom',
			})
			firstBackTime = Date.now()
			setTimeout(() => {
				firstBackTime = 0
			}, 2000)
		} else if (Date.now() - firstBackTime < 2000) {
			firstBackTime = Date.now()
			uni.exit()
		}
	})

	onExit(() => {
		console.log('App Exit')
	})
	// #endif
</script>

<style>
	/*每个页面公共css */
	.uni-row {
		flex-direction: row;
	}

	.uni-column {
		flex-direction: column;
	}
</style>

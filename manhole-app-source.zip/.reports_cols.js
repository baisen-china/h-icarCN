const { Client } = require('pg');
const ref = 'etxxigwpnhjjbebybdoz';
const PW = process.env.DB_PW;
const client = new Client({
  host: `aws-0-eu-north-1.pooler.supabase.com`, port: 6543,
  user: `postgres.${ref}`, password: PW, database: 'postgres',
  ssl: { rejectUnauthorized: false }, connectionTimeoutMillis: 15000, query_timeout: 30000,
});
(async () => {
  try {
    await client.connect();
    const cols = await client.query(
      `select column_name, data_type, is_nullable, column_default, is_identity
       from information_schema.columns where table_schema='public' and table_name='reports'
       order by ordinal_position`);
    console.log('=== reports 表列 ===');
    cols.rows.forEach(r => console.log(JSON.stringify(r)));
    const rls = await client.query(
      "select relname, relrowsecurity from pg_class where relname='reports'");
    console.log('=== reports RLS 当前状态 ===', JSON.stringify(rls.rows[0] || null));
    await client.end();
  } catch (e) { console.error('❌', e.message); try{await client.end();}catch(_){} process.exit(1); }
})();
